# RANGraph cover demo v1

Preserved on 9 October 2026 at the owner's request. This is the source-backed interactive cover with 1s/2s controls, before the proposed image-only deck redesign. The live route remains /demo/projects.

The ZIP preserves the route, component, scoped CSS, RANGraph model and golden trace, package versions, documentation, and three reviewed production captures. manifest.json records the source paths, bytes and SHA256 hashes.

This is a prototype snapshot, not a standalone application or full V3 backup. It uses the existing V3 root layout, fonts, HomeMotion, SignalTubes, content and attributed original cursor assets. Extract into a separate review folder. To restore later, compare and copy the route/component/CSS into C:\RESEARCH\portfolio v3, preserving unrelated newer work and model truth. Run the app checks after restoration. The existing component can also be mounted on a later demonstration route without replacing the homepage.

Owner approved the concept, but requested less initial information for the homepage. The saved diagram is suitable for a project detail or interactive demonstration. Do not treat its saved visual-review verdict as approval of a future deck.
